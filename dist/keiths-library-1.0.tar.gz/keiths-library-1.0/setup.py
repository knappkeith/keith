from distutils.core import setup

setup(name='keiths-library',
      version='1.0',
      py_modules=['array_tools', 'file_mngr'],
      )